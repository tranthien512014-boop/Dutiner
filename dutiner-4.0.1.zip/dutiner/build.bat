@echo off
cd /d "%~dp0"
call gradlew.bat build -x test --no-daemon && echo XONG: build\libs\dutiner-4.0.jar
pause
