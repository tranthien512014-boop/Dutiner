# Dutiner 1.0 (Fabric 1.21.11, Mojang mappings)
Build: `gradle build` (cần Java 21 + mạng) → `build/libs/dutiner-1.0.0.jar`, bỏ vào `mods/` cùng Fabric API.
Phím: **Right Shift** mở ClickGUI (chuột trái bật/đổi, chuột phải mở cài đặt). Config: `config/dutiner.json`.
Không dùng mixin: ESP vẽ bằng chiếu toán 3D→2D lên HUD → ít vỡ khi Minecraft đổi bản.
Phần chỉ nhạy phiên bản (nếu lỗi compile, sửa ở đây): DutinerClient (phím, HudRenderCallback), ClickGui (MouseButtonEvent/KeyEvent), Intel (ChunkStatus, getMinY), Manager (DeltaTracker), StaffAlert (getProfile().name()).
