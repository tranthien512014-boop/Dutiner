package dev.dutiner.core;
/** Giá trị mượt kiểu LARP: tiến dần tới target với easing theo thời gian (giây). */
public final class Anim {
    public double v, target; public double speed;
    public Anim(double init, double speed) { v = target = init; this.speed = speed; }
    public void set(double t) { target = t; }
    public void tick(double dt) { v += (target - v) * (1 - Math.exp(-speed * dt)); if (Math.abs(target - v) < 1e-3) v = target; }
    public static double outBack(double t) { double c = 1.70158; t -= 1; return 1 + (c + 1) * t * t * t + c * t * t; }
    public static double outCubic(double t) { t = 1 - t; return 1 - t * t * t; }
}
