package dev.dutiner.core;
import java.util.*;
/** Đếm sự kiện (block đổi, âm thanh, entity) theo chunk, giảm dần theo thời gian (half-life tính bằng tick). */
public final class ActivityTracker {
    private record Cell(double v, long t) {}
    private final Map<Long, Cell> map = new HashMap<>();
    private final double halfLife;
    public ActivityTracker(double halfLifeTicks) { this.halfLife = halfLifeTicks; }
    public static long key(int cx, int cz) { return ((long) cx << 32) | (cz & 0xffffffffL); }
    public static int kx(long k) { return (int) (k >> 32); }
    public static int kz(long k) { return (int) k; }
    public void hit(int cx, int cz, double w, long now) { long k = key(cx, cz); map.put(k, new Cell(get(k, now) + w, now)); }
    public double get(long k, long now) {
        Cell c = map.get(k); if (c == null) return 0;
        return c.v * Math.pow(0.5, (now - c.t) / halfLife);
    }
    public void prune(long now) { map.values().removeIf(c -> c.v * Math.pow(0.5, (now - c.t) / halfLife) < 0.05); }
    public void clear() { map.clear(); }
}
