package dev.dutiner.core;
/** Chiếu điểm thế giới → toạ độ màn hình bằng toán thuần (không cần render pipeline của MC). */
public final class Projector {
    private final double cx, cy, cz, fx, fy, fz, rx, ry, rz, ux, uy, uz, tanHalfV, aspect; private final int w, h;
    /** yaw/pitch theo chuẩn Minecraft (độ), fov dọc (độ). */
    public Projector(double camX, double camY, double camZ, double yawDeg, double pitchDeg, double fovDeg, int w, int h) {
        cx = camX; cy = camY; cz = camZ; this.w = w; this.h = h;
        double yaw = Math.toRadians(yawDeg), pit = Math.toRadians(pitchDeg);
        fx = -Math.sin(yaw) * Math.cos(pit); fy = -Math.sin(pit); fz = Math.cos(yaw) * Math.cos(pit);
        rx = -Math.cos(yaw); ry = 0; rz = -Math.sin(yaw);               // phải = f × up(0,1,0) chuẩn hoá
        ux = ry * fz - rz * fy; uy = rz * fx - rx * fz; uz = rx * fy - ry * fx; // up = r × f
        tanHalfV = Math.tan(Math.toRadians(fovDeg) / 2); aspect = (double) w / h;
    }
    /** @return {x, y, depth} hoặc null nếu nằm sau camera. */
    public double[] project(double x, double y, double z) {
        double dx = x - cx, dy = y - cy, dz = z - cz;
        double d = dx * fx + dy * fy + dz * fz; if (d < 0.05) return null;
        double sx = (dx * rx + dy * ry + dz * rz) / (d * tanHalfV * aspect);
        double sy = (dx * ux + dy * uy + dz * uz) / (d * tanHalfV);
        return new double[]{(sx + 1) * 0.5 * w, (1 - sy) * 0.5 * h, d};
    }
    /** Hộp 2D bao quanh khối [x0,x1]×[y0,y1]×[z0,z1]; null nếu cả 8 đỉnh đều sau camera. */
    public double[] box(double x0, double y0, double z0, double x1, double y1, double z1) {
        double minX = 1e9, minY = 1e9, maxX = -1e9, maxY = -1e9, dep = 1e9; int ok = 0;
        for (int i = 0; i < 8; i++) {
            double[] p = project((i & 1) == 0 ? x0 : x1, (i & 2) == 0 ? y0 : y1, (i & 4) == 0 ? z0 : z1);
            if (p == null) continue; ok++;
            minX = Math.min(minX, p[0]); maxX = Math.max(maxX, p[0]); minY = Math.min(minY, p[1]); maxY = Math.max(maxY, p[1]); dep = Math.min(dep, p[2]);
        }
        return ok < 8 ? null : new double[]{minX, minY, maxX, maxY, dep};
    }
}
