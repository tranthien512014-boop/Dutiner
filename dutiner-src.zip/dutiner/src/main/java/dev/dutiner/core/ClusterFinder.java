package dev.dutiner.core;
import java.util.*;
/** Gom các chunk có điểm cao nằm gần nhau (cho phép hở 1 chunk) thành 1 "base". */
public final class ClusterFinder {
    public record Cluster(int cx, int cz, int size, double total, double peak, int minCx, int minCz, int maxCx, int maxCz) {
        public int blockX() { return cx * 16 + 8; }
        public int blockZ() { return cz * 16 + 8; }
    }
    public static List<Cluster> find(Map<Long, Double> scores, double threshold, int gap) {
        Set<Long> todo = new HashSet<>();
        scores.forEach((k, v) -> { if (v >= threshold) todo.add(k); });
        List<Cluster> out = new ArrayList<>();
        while (!todo.isEmpty()) {
            long start = todo.iterator().next(); todo.remove(start);
            ArrayDeque<Long> q = new ArrayDeque<>(List.of(start));
            double tot = 0, peak = 0, wx = 0, wz = 0; int n = 0;
            int mnx = Integer.MAX_VALUE, mnz = Integer.MAX_VALUE, mxx = Integer.MIN_VALUE, mxz = Integer.MIN_VALUE;
            while (!q.isEmpty()) {
                long k = q.poll(); int x = ActivityTracker.kx(k), z = ActivityTracker.kz(k); double s = scores.get(k);
                tot += s; peak = Math.max(peak, s); wx += x * s; wz += z * s; n++;
                mnx = Math.min(mnx, x); mxx = Math.max(mxx, x); mnz = Math.min(mnz, z); mxz = Math.max(mxz, z);
                for (int dx = -gap - 1; dx <= gap + 1; dx++) for (int dz = -gap - 1; dz <= gap + 1; dz++) {
                    long nk = ActivityTracker.key(x + dx, z + dz);
                    if (todo.remove(nk)) q.add(nk);
                }
            }
            out.add(new Cluster((int) Math.round(wx / tot), (int) Math.round(wz / tot), n, tot, peak, mnx, mnz, mxx, mxz));
        }
        out.sort(Comparator.comparingDouble(Cluster::total).reversed());
        return out;
    }
}
