package dev.dutiner.core;
import java.util.EnumMap;
/** Điểm nghi ngờ của 1 chunk. Dùng log để 1000 block gỗ không lấn át 1 spawner/beacon. */
public final class ChunkScorer {
    public final EnumMap<Kind, Integer> counts = new EnumMap<>(Kind.class);
    public void add(Kind k) { if (k != Kind.OTHER) counts.merge(k, 1, Integer::sum); }
    public int count(Kind k) { return counts.getOrDefault(k, 0); }
    /** @param activity điểm hoạt động (đã decay) từ ActivityTracker */
    public double score(double activity) {
        double s = 0;
        for (var e : counts.entrySet()) {
            Kind k = e.getKey();
            double cap = (k == Kind.SPAWNER || k == Kind.BEACON) ? 1.5 : 1.0;   // spawner tự nhiên có sẵn → bớt trọng
            s += k.weight * Math.log1p(e.getValue()) * cap;
        }
        // Tổ hợp là dấu hiệu base thật: kho + hopper + redstone cùng chunk
        if (count(Kind.STORAGE) + count(Kind.SHULKER) > 0 && count(Kind.HOPPER) > 0) s *= 1.35;
        if (count(Kind.DEEPLIGHT) > 0 && (count(Kind.STORAGE) + count(Kind.HOPPER) + count(Kind.BED) > 0)) s *= 1.3;
        if (count(Kind.BED) > 0 && count(Kind.STORAGE) > 0) s *= 1.25;
        if (count(Kind.SPAWNER) > 0 && (count(Kind.BUILD) + count(Kind.LIGHT)) > 4) s *= 1.3; // spawner có đèn/tường = farm
        return s + Math.min(activity, 12) * 1.1;
    }
}
