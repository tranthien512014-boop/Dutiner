package dev.dutiner.core;
/** Phân loại block theo id (chuỗi) — thuần Java, không phụ thuộc Minecraft. */
public enum Kind {
    SPAWNER(6.0), STORAGE(3.0), SHULKER(4.0), ENDER(2.0), HOPPER(3.5), BEACON(8.0), UTILITY(2.0), BED(2.5),
    REDSTONE(1.5), BUILD(0.9), GLASS(1.4), LIGHT(1.2), DEEPLIGHT(4.5), OBSIDIAN(2.2), RAIL(0.4), SIGN(1.8), OTHER(0);
    public final double weight;
    Kind(double w) { weight = w; }

    /** Block phát sáng xuất hiện tự nhiên (không tính là dấu hiệu người chơi). */
    public static boolean naturalLight(String id) {
        return id.equals("lava") || id.equals("magma_block") || id.equals("fire") || id.equals("soul_fire") || id.contains("amethyst")
            || id.equals("glow_lichen") || id.equals("sculk_catalyst") || id.equals("sculk_sensor") || id.equals("calibrated_sculk_sensor")
            || id.equals("shroomlight") || id.contains("froglight") || id.equals("end_portal") || id.equals("nether_portal") || id.equals("end_portal_frame")
            || id.equals("redstone_ore") || id.equals("deepslate_redstone_ore") || id.equals("crying_obsidian") || id.equals("cave_vines") || id.equals("cave_vines_plant")
            || id.equals("candle") || id.equals("conduit") || id.equals("end_gateway") || id.equals("vault") || id.equals("trial_spawner") || id.equals("spawner") || id.equals("beacon");
    }
    public static Kind of(String id) {
        if (id.equals("air") || id.equals("cave_air") || id.equals("void_air")) return OTHER;
        if (id.equals("spawner") || id.equals("trial_spawner")) return SPAWNER;
        if (id.endsWith("shulker_box")) return SHULKER;
        if (id.equals("ender_chest")) return ENDER;
        if (id.equals("chest") || id.equals("trapped_chest") || id.equals("barrel")) return STORAGE;
        if (id.equals("hopper") || id.equals("dropper") || id.equals("dispenser") || id.equals("crafter")) return HOPPER;
        if (id.equals("beacon") || id.equals("conduit")) return BEACON;
        if (id.equals("anvil") || id.equals("chipped_anvil") || id.equals("damaged_anvil") || id.equals("enchanting_table")
            || id.equals("brewing_stand") || id.equals("furnace") || id.equals("blast_furnace") || id.equals("smoker")
            || id.equals("crafting_table") || id.equals("smithing_table") || id.equals("grindstone")) return UTILITY;
        if (id.endsWith("_bed")) return BED;
        if (id.equals("repeater") || id.equals("comparator") || id.equals("observer") || id.equals("piston")
            || id.equals("sticky_piston") || id.equals("redstone_lamp") || id.equals("lever") || id.equals("target")) return REDSTONE;
        if (id.equals("obsidian") || id.equals("crying_obsidian") || id.equals("respawn_anchor")) return OBSIDIAN;
        if (id.endsWith("rail")) return RAIL;
        if (id.endsWith("_sign") || id.endsWith("_hanging_sign")) return SIGN;
        if (id.endsWith("glass") || id.endsWith("glass_pane")) return GLASS;
        if (id.equals("torch") || id.equals("wall_torch") || id.equals("lantern") || id.equals("glowstone")
            || id.equals("sea_lantern") || id.equals("shroomlight") || id.equals("soul_lantern")) return LIGHT;
        if (id.endsWith("_planks") || id.endsWith("_concrete") || id.endsWith("_wool") || id.endsWith("_terracotta")
            || id.endsWith("bricks") || id.endsWith("_slab") || id.endsWith("_stairs") || id.endsWith("_door")
            || id.endsWith("_trapdoor") || id.endsWith("_fence") || id.endsWith("_fence_gate") || id.equals("bookshelf")
            || id.equals("iron_block") || id.equals("gold_block") || id.equals("diamond_block") || id.equals("netherite_block")
            || id.equals("emerald_block") || id.equals("smooth_stone") || id.equals("polished_andesite")) return BUILD;
        return OTHER;
    }
}
