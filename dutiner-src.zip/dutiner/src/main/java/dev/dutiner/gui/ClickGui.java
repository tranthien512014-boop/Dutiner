package dev.dutiner.gui;
import dev.dutiner.core.Anim;
import dev.dutiner.mod.Module;
import dev.dutiner.mod.Manager;
import dev.dutiner.mod.Setting;
import dev.dutiner.mod.Draw;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;
import java.util.*;
/** ClickGUI kiểu LARP: panel theo nhóm, hover/toggle/mở rộng mượt. Chuột trái = bật/đổi, chuột phải = mở cài đặt / đổi ngược. */
public final class ClickGui extends Screen {
    private record Hit(int x0, int y0, int x1, int y1, Module m, Setting s) { boolean in(double x, double y) { return x >= x0 && x < x1 && y >= y0 && y < y1; } }
    private final List<Hit> hits = new ArrayList<>(); private final Anim fade = new Anim(0, 12); private long last = System.nanoTime(); private Module tip;
    public ClickGui() { super(Component.literal("Dutiner")); fade.set(1); }
    @Override public boolean isPauseScreen() { return false; }
    @Override public void render(GuiGraphics g, int mx, int my, float pt) {
        long n = System.nanoTime(); double dt = Math.min(0.1, (n - last) / 1e9); last = n; fade.tick(dt); double f = fade.v; int fa = (int) (255 * f);
        g.fill(0, 0, width, height, Draw.rgb(0x000000, (int) (120 * f))); hits.clear(); tip = null;
        int px = Math.max(8, (width - Module.Cat.values().length * 134) / 2);
        for (Module.Cat cat : Module.Cat.values()) {
            int x = px, y = 24 + (int) ((1 - Anim.outCubic(f)) * -24), w = 126; px += 134;
            g.fill(x, y, x + w, y + 20, Draw.rgb(0x15151F, (int) (235 * f))); g.fill(x, y + 18, x + w, y + 20, Draw.rgb(Draw.lerp(0xFF7A5CFF, 0xFF5CFFF1, cat.ordinal() / 2.0), fa));
            Draw.text(g, cat.label, x + 8, y + 6, Draw.rgb(0xFFFFFF, fa)); y += 22;
            for (Module m : Manager.all) {
                if (m.cat != cat) continue;
                m.hover.set(mx >= x && mx < x + w && my >= y && my < y + 18 ? 1 : 0); m.hover.tick(dt); m.toggle.set(m.enabled ? 1 : 0); m.toggle.tick(dt); m.open.set(m.expanded ? 1 : 0); m.open.tick(dt);
                g.fill(x, y, x + w, y + 18, Draw.lerp(Draw.rgb(0x1B1B28, (int) (225 * f)), Draw.rgb(0x2A2A40, (int) (235 * f)), m.hover.v));
                int accent = Draw.lerp(0xFF3A3A4C, 0xFF7A5CFF, m.toggle.v); g.fill(x, y, x + 3, y + 18, Draw.rgb(accent, fa));
                Draw.text(g, m.name, x + 9, y + 5, Draw.rgb(Draw.lerp(0xFF9AA0B5, 0xFFFFFFFF, m.toggle.v), fa));
                int px2 = x + w - 22; g.fill(px2, y + 6, px2 + 14, y + 12, Draw.rgb(0x0C0C14, fa)); int kx = px2 + (int) (m.toggle.v * 8); g.fill(kx, y + 5, kx + 6, y + 13, Draw.rgb(accent, fa));
                hits.add(new Hit(x, y, x + w, y + 18, m, null)); if (m.hover.v > .5) tip = m; y += 18;
                if (m.open.v > 0.02) {
                    double h = m.settings.size() * 14 * m.open.v; g.fill(x, y, x + w, y + (int) h, Draw.rgb(0x0F0F18, (int) (225 * f)));
                    int sy = y; for (Setting s : m.settings) {
                        int ry = y + (int) ((sy - y) * 1.0); if (m.open.v > .85) {
                            Draw.text(g, s.name, x + 9, sy + 3, Draw.rgb(0xB8BDD0, fa)); String v = s.shown(); Draw.text(g, v, x + w - 6 - Draw.width(v), sy + 3, Draw.rgb(s.type == Setting.T.BOOL && s.b ? 0x5CFFB0 : 0xFFFFFF, fa));
                            if (s.type == Setting.T.NUM) { double t = (s.n - s.min) / (s.max - s.min); g.fill(x + 9, sy + 12, x + 9 + (int) ((w - 18) * t), sy + 13, Draw.rgb(0x7A5CFF, fa)); }
                            hits.add(new Hit(x, sy, x + w, sy + 14, m, s));
                        }
                        sy += 14 * (m.open.v > .85 ? 1 : 0) + (m.open.v > .85 ? 0 : 0);
                    }
                    y += (int) (m.settings.size() * 14 * (m.open.v > .85 ? 1 : m.open.v));
                }
                y += 1;
            }
        }
        if (tip != null) { String d = tip.desc; g.fill(mx + 8, my + 8, mx + 14 + Draw.width(d), my + 22, 0xE0101018); Draw.text(g, d, mx + 11, my + 11, 0xFFFFFFFF); }
    }
    @Override public boolean mouseClicked(MouseButtonEvent e, boolean dbl) {
        for (Hit h : hits) if (h.in(e.x(), e.y())) {
            boolean right = e.button() == 1;
            if (h.s != null) { h.s.click(right); Manager.dirty = true; } else if (right) h.m.expanded = !h.m.expanded; else h.m.flip();
            return true;
        }
        return super.mouseClicked(e, dbl);
    }
    @Override public boolean keyPressed(KeyEvent e) { if (e.key() == GLFW.GLFW_KEY_RIGHT_SHIFT) { onClose(); return true; } return super.keyPressed(e); }
    @Override public void removed() { Manager.save(); }
}
