package dev.dutiner;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.resources.Identifier;
import dev.dutiner.gui.ClickGui;
import dev.dutiner.mod.Manager;
import dev.dutiner.mod.Intel;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.*;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import org.lwjgl.glfw.GLFW;
public final class DutinerClient implements ClientModInitializer {
    private boolean down;
    @Override public void onInitializeClient() {
        Manager.init();
        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            boolean k = GLFW.glfwGetKey(mc.getWindow().handle(), GLFW.GLFW_KEY_RIGHT_SHIFT) == GLFW.GLFW_PRESS;
            if (k && !down && mc.screen == null && mc.player != null) mc.setScreen(new ClickGui());
            down = k; Manager.tick(mc);
        });
        HudElementRegistry.addFirst(Identifier.fromNamespaceAndPath("dutiner", "hud"), (g, tc) -> Manager.hud(g));
        ClientPlayConnectionEvents.DISCONNECT.register((h, mc) -> Intel.I.reset());
        ClientLifecycleEvents.CLIENT_STOPPING.register(mc -> Manager.save());
    }
}
