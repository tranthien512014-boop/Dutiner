package dev.dutiner.mod;
import com.google.gson.*;
public final class Setting {
    public enum T { BOOL, NUM, MODE }
    public final String name; public final T type;
    public boolean b; public double n, min, max, step; public String[] modes = {}; public int idx;
    private Setting(String name, T t) { this.name = name; this.type = t; }
    public static Setting bool(String n, boolean d) { Setting s = new Setting(n, T.BOOL); s.b = d; return s; }
    public static Setting num(String n, double d, double min, double max, double step) { Setting s = new Setting(n, T.NUM); s.n = d; s.min = min; s.max = max; s.step = step; return s; }
    public static Setting mode(String n, int i, String... m) { Setting s = new Setting(n, T.MODE); s.idx = i; s.modes = m; return s; }
    public int i() { return (int) Math.round(n); }
    public String mode() { return modes[idx]; }
    public String shown() { return switch (type) { case BOOL -> b ? "ON" : "OFF"; case NUM -> step >= 1 ? String.valueOf((int) n) : String.format("%.1f", n); case MODE -> mode(); }; }
    public void click(boolean right) {
        switch (type) {
            case BOOL -> b = !b;
            case NUM -> n = Math.max(min, Math.min(max, n + (right ? -step : step)));
            case MODE -> idx = (idx + (right ? modes.length - 1 : 1)) % modes.length;
        }
    }
    public JsonElement save() { return switch (type) { case BOOL -> new JsonPrimitive(b); case NUM -> new JsonPrimitive(n); case MODE -> new JsonPrimitive(idx); }; }
    public void load(JsonElement e) {
        try { switch (type) { case BOOL -> b = e.getAsBoolean(); case NUM -> n = Math.max(min, Math.min(max, e.getAsDouble())); case MODE -> idx = Math.floorMod(e.getAsInt(), modes.length); } } catch (Exception ignored) {}
    }
}
