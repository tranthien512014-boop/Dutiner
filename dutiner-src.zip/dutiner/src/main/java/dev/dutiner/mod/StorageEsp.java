package dev.dutiner.mod;
import dev.dutiner.core.Kind;
import net.minecraft.client.gui.GuiGraphics;
import java.util.*;
public final class StorageEsp extends Module {
    public final Setting range = add(Setting.num("Range", 64, 16, 128, 8)), chests = add(Setting.bool("Chests", true)), shulkers = add(Setting.bool("Shulkers", true)), ender = add(Setting.bool("Ender chest", true)),
        hoppers = add(Setting.bool("Hoppers", false)), spawners = add(Setting.bool("Spawners", true)), beacons = add(Setting.bool("Beacons", true)), utility = add(Setting.bool("Utility", false)), deep = add(Setting.bool("Deep lights", true)), max = add(Setting.num("Max boxes", 120, 20, 300, 10));
    public StorageEsp() { super("Storage ESP", Cat.RAID, "Khung quanh rương, shulker, hopper, spawner, beacon trong base"); }
    private boolean want(Kind k) {
        return switch (k) { case STORAGE -> chests.b; case SHULKER -> shulkers.b; case ENDER -> ender.b; case HOPPER -> hoppers.b; case SPAWNER -> spawners.b; case BEACON -> beacons.b; case UTILITY -> utility.b; case DEEPLIGHT -> deep.b; default -> false; };
    }
    static int color(Kind k) { return switch (k) { case STORAGE -> 0xFFFFA630; case SHULKER -> 0xFFE05CFF; case ENDER -> 0xFF7A5CFF; case HOPPER -> 0xFF8A8A8A; case SPAWNER -> 0xFFFF3D6E; case BEACON -> 0xFF5CFFF1; case DEEPLIGHT -> 0xFFFFF27A; default -> 0xFFFFFFFF; }; }
    @Override public void hud(GuiGraphics g, Ctx c) {
        List<Intel.Hit> l = new ArrayList<>();
        for (var res : Intel.I.chunks.values()) for (var h : res.hits) if (want(h.kind()) && Esp.dist(c, h.pos()) <= range.n) l.add(h);
        l.sort(Comparator.comparingDouble(h -> Esp.dist(c, h.pos()))); int n = 0;
        for (var h : l) { if (n >= max.i()) break; if (Esp.block(g, c, h.pos(), color(h.kind()), h.kind() == Kind.STORAGE ? null : (h.kind() == Kind.DEEPLIGHT ? "deep light" : h.id().replace('_', ' ')))) n++; }
    }
}
