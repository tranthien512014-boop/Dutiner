package dev.dutiner.mod;
import dev.dutiner.core.*;
import net.minecraft.client.gui.GuiGraphics;
import java.util.*;
public final class BaseFinder extends Module {
    public final Setting radius = add(Setting.num("Radius", 24, 8, 32, 2)), threshold = add(Setting.num("Threshold", 6, 2, 40, 1)),
        gap = add(Setting.num("Gap chunks", 1, 0, 3, 1)), maxBases = add(Setting.num("Max bases", 5, 1, 12, 1)),
        tracers = add(Setting.bool("Tracers", true)), panel = add(Setting.bool("Info panel", true)), minSize = add(Setting.num("Min chunks", 1, 1, 10, 1));
    public record Base(ClusterFinder.Cluster c, double y, EnumMap<Kind, Integer> k) {}
    public List<Base> bases = List.of(); private long at = -99;
    private static final String[] DIR = {"N", "NE", "E", "SE", "S", "SW", "W", "NW"};
    public BaseFinder() { super("Base Finder", Cat.RAID, "Gom các chunk sus thành cụm base, hiện hướng, khoảng cách, thành phần"); }
    @Override public String info() { return String.valueOf(bases.size()); }
    private void refresh() {
        if (Intel.I.tick - at < 20) return; at = Intel.I.tick;
        List<Base> out = new ArrayList<>();
        for (var c : ClusterFinder.find(Intel.I.scores(), threshold.n, gap.i())) {
            if (c.size() < minSize.i()) continue;
            EnumMap<Kind, Integer> k = new EnumMap<>(Kind.class); double sy = 0; int n = 0;
            for (int x = c.minCx(); x <= c.maxCx(); x++) for (int z = c.minCz(); z <= c.maxCz(); z++) {
                var r = Intel.I.chunks.get(ActivityTracker.key(x, z)); if (r == null) continue;
                r.sc.counts.forEach((a, b) -> k.merge(a, b, Integer::sum)); if (r.ny > 0) { sy += r.sumY; n += r.ny; }
            }
            out.add(new Base(c, n == 0 ? 64 : sy / n, k));
        }
        bases = out;
    }
    public static String dir(double dx, double dz) { return DIR[(int) Math.round(Math.toDegrees(Math.atan2(dx, -dz)) / 45 + 8) % 8]; }
    @Override public void hud(GuiGraphics g, Ctx c) {
        refresh(); int y = 34, shown = 0;
        for (Base b : bases) {
            if (shown++ >= maxBases.i()) break;
            double dx = b.c().blockX() - c.eye().x, dz = b.c().blockZ() - c.eye().z, d = Math.hypot(dx, dz);
            if (d > radius.n * 16 + 32) continue;
            int col = Draw.heat(b.c().total() / 80.0) | 0xFF000000;
            double[] p = c.proj().project(b.c().blockX(), b.y(), b.c().blockZ());
            if (p != null && p[0] > 0 && p[0] < c.w() && p[1] > 0 && p[1] < c.h()) {
                Draw.outline(g, p[0] - 5, p[1] - 5, p[0] + 5, p[1] + 5, col);
                Draw.textC(g, String.format("BASE #%d  %dm", shown, (int) d), (int) p[0], (int) p[1] - 18, col);
            }
            if (tracers.b && p != null) Draw.line(g, c.w() / 2.0, c.h(), p[0], p[1], Draw.rgb(col, 140), c.w(), c.h());
            if (panel.b) {
                var k = b.k(); String s = String.format("#%d %s %dm [%d,%d] %dch ★%.0f  chest %d hop %d spw %d bcn %d", shown, dir(dx, dz), (int) d, b.c().blockX(), b.c().blockZ(), b.c().size(), b.c().total(),
                    k.getOrDefault(Kind.STORAGE, 0) + k.getOrDefault(Kind.SHULKER, 0) + k.getOrDefault(Kind.ENDER, 0), k.getOrDefault(Kind.HOPPER, 0), k.getOrDefault(Kind.SPAWNER, 0), k.getOrDefault(Kind.BEACON, 0));
                g.fill(4, y - 2, 10 + Draw.width(s), y + 10, 0x99000000); g.fill(4, y - 2, 6, y + 10, col); Draw.text(g, s, 9, y, 0xFFFFFFFF); y += 13;
            }
        }
    }
}
