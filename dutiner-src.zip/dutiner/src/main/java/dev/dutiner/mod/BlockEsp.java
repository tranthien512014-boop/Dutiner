package dev.dutiner.mod;
import net.minecraft.client.gui.GuiGraphics;
import java.util.*;
public final class BlockEsp extends Module {
    public final Setting preset = add(Setting.mode("Preset", 0, "Ores", "Debris", "Spawners", "Valuables", "All")), radius = add(Setting.num("Range", 48, 16, 128, 8)),
        maxBoxes = add(Setting.num("Max boxes", 150, 20, 400, 10)), labels = add(Setting.bool("Labels", true)), tracers = add(Setting.bool("Tracers", false));
    static final Set<String> ORES = Set.of("diamond_ore", "deepslate_diamond_ore", "emerald_ore", "deepslate_emerald_ore", "ancient_debris", "gold_ore", "deepslate_gold_ore", "nether_gold_ore", "lapis_ore", "deepslate_lapis_ore", "redstone_ore", "deepslate_redstone_ore", "iron_ore", "deepslate_iron_ore", "nether_quartz_ore");
    static final Set<String> VAL = Set.of("diamond_block", "netherite_block", "emerald_block", "gold_block", "beacon", "enchanting_table", "ender_chest", "end_portal_frame", "spawner", "trial_spawner", "reinforced_deepslate", "budding_amethyst");
    public BlockEsp() { super("Block ESP", Cat.VISUAL, "Khung 2D quanh block bạn chọn (quặng, debris, spawner, đồ giá trị) xuyên tường"); }
    public Set<String> watchSet() {
        Set<String> s = new HashSet<>();
        switch (preset.mode()) { case "Ores" -> s.addAll(ORES); case "Debris" -> s.add("ancient_debris"); case "Spawners" -> { s.add("spawner"); s.add("trial_spawner"); }
            case "Valuables" -> s.addAll(VAL); default -> { s.addAll(ORES); s.addAll(VAL); } }
        return s;
    }
    static int colorOf(String id) {
        if (id.contains("diamond")) return 0xFF4DE8FF; if (id.contains("emerald")) return 0xFF3DFF6B; if (id.contains("debris") || id.contains("netherite")) return 0xFFB5651D;
        if (id.contains("gold")) return 0xFFFFD84A; if (id.contains("redstone")) return 0xFFFF3030; if (id.contains("lapis")) return 0xFF3A5BFF; if (id.contains("spawner")) return 0xFFB84DFF;
        if (id.contains("iron")) return 0xFFE0C0A0; return 0xFFFFFFFF;
    }
    @Override public void hud(GuiGraphics g, Ctx c) {
        Set<String> w = Intel.I.watch; if (w.isEmpty()) return; double r2 = radius.n * radius.n; List<Intel.Hit> l = new ArrayList<>();
        for (var res : Intel.I.chunks.values()) for (var h : res.hits) if (w.contains(h.id()) && Esp.dist(c, h.pos()) <= radius.n) l.add(h);
        l.sort(Comparator.comparingDouble(h -> Esp.dist(c, h.pos())));
        int n = 0;
        for (var h : l) {
            if (n >= maxBoxes.i()) break; int col = colorOf(h.id());
            if (Esp.block(g, c, h.pos(), col, labels.b ? h.id().replace('_', ' ') + " " + (int) Esp.dist(c, h.pos()) + "m" : null)) n++;
            if (tracers.b && n <= 12) { double[] p = c.proj().project(net.minecraft.core.BlockPos.getX(h.pos()) + .5, net.minecraft.core.BlockPos.getY(h.pos()) + .5, net.minecraft.core.BlockPos.getZ(h.pos()) + .5); if (p != null) Draw.line(g, c.w() / 2.0, c.h(), p[0], p[1], Draw.rgb(col, 120), c.w(), c.h()); }
        }
    }
}
