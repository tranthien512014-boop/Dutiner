package dev.dutiner.mod;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.core.BlockPos;
public final class Esp {
    /** Vẽ khung 2D quanh 1 block (nếu cả 8 đỉnh trước camera) + nhãn. @return true nếu đã vẽ */
    public static boolean block(GuiGraphics g, Ctx c, long pos, int color, String label) {
        int x = BlockPos.getX(pos), y = BlockPos.getY(pos), z = BlockPos.getZ(pos);
        double[] b = c.proj().box(x, y, z, x + 1, y + 1, z + 1);
        if (b == null || b[2] > c.w() || b[3] > c.h() + 400 || b[0] < -400 || b[1] < -400 || b[3] < 0 || b[2] < 0) return false;
        Draw.outline(g, b[0], b[1], b[2], b[3], color);
        if (label != null) Draw.text(g, label, (int) b[0], (int) b[1] - 10, color);
        return true;
    }
    public static double dist(Ctx c, long pos) {
        double dx = BlockPos.getX(pos) + .5 - c.eye().x, dy = BlockPos.getY(pos) + .5 - c.eye().y, dz = BlockPos.getZ(pos) + .5 - c.eye().z;
        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }
}
