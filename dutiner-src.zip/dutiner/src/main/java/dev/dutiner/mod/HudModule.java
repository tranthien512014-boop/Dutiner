package dev.dutiner.mod;
import net.minecraft.client.gui.GuiGraphics;
import java.util.*;
public final class HudModule extends Module {
    public final Setting arraylist = add(Setting.bool("Module list", true)), watermark = add(Setting.bool("Watermark", true)), stats = add(Setting.bool("Scan stats", false));
    public HudModule() { super("HUD", Cat.UTILITY, "Watermark và danh sách module có animation"); enabled = true; toggle.v = toggle.target = 1; }
    @Override public void hud(GuiGraphics g, Ctx c) {
        long t = System.currentTimeMillis();
        if (watermark.b) {
            String s = "Dutiner"; int w = Draw.width(s) + 14;
            g.fill(4, 4, 4 + w, 18, 0xA0101018); g.fill(4, 4, 6, 18, Draw.lerp(0xFF7A5CFF, 0xFF5CFFF1, (Math.sin(t / 600.0) + 1) / 2));
            Draw.text(g, s, 11, 7, 0xFFFFFFFF);
            if (stats.b) Draw.text(g, String.format("chunks %d  scan %.1fms", Intel.I.chunks.size(), Intel.I.lastMs), 8 + w, 7, 0xFF9AA0B5);
        }
        if (!arraylist.b) return;
        List<Module> l = new ArrayList<>(); for (Module m : Manager.all) { m.slide.set(m.enabled ? 1 : 0); m.slide.tick(c.dt()); if (m.slide.v > 0.01 && m != this) l.add(m); }
        l.sort(Comparator.comparingInt((Module m) -> -Draw.width(m.name + m.info())));
        int y = 4;
        for (Module m : l) {
            String s = m.name + (m.info().isEmpty() ? "" : " §7" + m.info()); int w = Draw.width(s) + 10; double k = m.slide.v;
            int x = (int) (c.w() - w * k); int a = (int) (200 * k);
            g.fill(x - 2, y, c.w(), y + 12, Draw.rgb(0x101018, a)); g.fill(c.w() - 2, y, c.w(), y + 12, Draw.rgb(Draw.lerp(0xFF7A5CFF, 0xFF5CFFF1, (y % 120) / 120.0), a));
            Draw.text(g, s, x + 3, y + 2, Draw.rgb(0xFFFFFF, Math.max(5, a))); y += (int) (12 * k);
        }
    }
}
