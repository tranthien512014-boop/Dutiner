package dev.dutiner.mod;
import net.minecraft.client.CameraType;
import net.minecraft.client.Minecraft;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.phys.Vec3;
public final class Freecam extends Module {
    public static Freecam INSTANCE;
    public final Setting speed = add(Setting.num("Speed", 1.0, 0.1, 10.0, 0.1));
    public final Setting vertical = add(Setting.num("Vertical", 1.0, 0.1, 5.0, 0.1));
    public final Setting body = add(Setting.bool("Show body", true));
    public boolean live;
    public float camYaw, camPitch;
    private Vec3 pos = Vec3.ZERO, prev = Vec3.ZERO;
    private boolean wasFly; private CameraType wasView; private boolean pushedView;
    public Freecam() { super("Freecam", Cat.UTILITY, "Camera tách khỏi người chơi, bạn bay tự do mà nhân vật đứng im"); INSTANCE = this; }
    @Override public void onEnable() {
        Minecraft mc = Minecraft.getInstance(); if (mc.player == null || mc.level == null) { enabled = false; return; }
        wasFly = mc.player.getAbilities().flying;
        double ey = mc.player.getEyeHeight(Pose.STANDING);
        pos = prev = new Vec3(mc.player.getX(), mc.player.getY() + ey, mc.player.getZ());
        camYaw = mc.player.getYRot(); camPitch = mc.player.getXRot();
        if (body.b && mc.options.getCameraType().isFirstPerson()) {
            wasView = mc.options.getCameraType(); mc.options.setCameraType(CameraType.THIRD_PERSON_BACK); pushedView = true;
        }
        mc.smartCull = false; live = true;
    }
    @Override public void onDisable() {
        live = false; Minecraft mc = Minecraft.getInstance();
        mc.smartCull = true;
        if (pushedView) { mc.options.setCameraType(wasView); pushedView = false; }
        if (mc.player != null) mc.player.getAbilities().flying = wasFly;
    }
    @Override public void tick(Minecraft mc) {
        if (!live || mc.player == null || mc.screen != null) return;
        prev = pos;
        var opts = mc.options;
        double fwd  = (opts.keyUp.isDown()    ? 1 : 0) - (opts.keyDown.isDown()  ? 1 : 0);
        double side = (opts.keyLeft.isDown()   ? 1 : 0) - (opts.keyRight.isDown() ? 1 : 0);
        double rise = (opts.keyJump.isDown()   ? 1 : 0) - (opts.keyShift.isDown() ? 1 : 0);
        double sp = speed.n * 0.5;
        float yr = (float) Math.toRadians(camYaw);
        double fx = -Math.sin(yr), fz = Math.cos(yr);
        pos = pos.add(
            (fx * fwd + fz * side) * sp,
            rise * sp * vertical.n,
            (fz * fwd - fx * side) * sp
        );
        mc.player.getAbilities().flying = false;
        mc.player.setDeltaMovement(0, Math.min(0, mc.player.getDeltaMovement().y), 0);
    }
    public double lx(float pt) { return Mth.lerp(pt, prev.x, pos.x); }
    public double ly(float pt) { return Mth.lerp(pt, prev.y, pos.y); }
    public double lz(float pt) { return Mth.lerp(pt, prev.z, pos.z); }
}
