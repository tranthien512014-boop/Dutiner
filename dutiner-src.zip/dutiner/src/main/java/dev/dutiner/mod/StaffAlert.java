package dev.dutiner.mod;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.network.chat.Component;
import java.util.*;
public final class StaffAlert extends Module {
    public final Setting chat = add(Setting.bool("Chat message", true)), banner = add(Setting.bool("Banner", true)), beep = add(Setting.bool("Sound", true));
    static final String[] MARK = {"\u2605", "\u2606", "\u2726", "\u2727", "\u272A", "\u272F", "\u2730", "\u2B50"};
    static final String[] PAT = {"owner", "sr-", "senior", "moderator", "administrator", "developer", "admin", "mod", "helper", "owner", "staff", "manager", "dev", "support", "trial", "sr", "[gm]"};
    private final Set<String> seen = new HashSet<>(); private String last = ""; private long until;
    public StaffAlert() { super("Staff Alert", Cat.UTILITY, "Cảnh báo khi người có tag staff trong tab list"); }
    @Override public void onEnable() { seen.clear(); }
    @Override public void tick(Minecraft mc) {
        if (mc.getConnection() == null || mc.player == null || mc.player.tickCount % 20 != 0) return;
        Set<String> now = new HashSet<>();
        for (PlayerInfo pi : mc.getConnection().getOnlinePlayers()) {
            String name = pi.getProfile().name(), disp = pi.getTabListDisplayName() == null ? "" : pi.getTabListDisplayName().getString();
            if (name.equals(mc.player.getName().getString())) continue;
            String low = disp.toLowerCase(Locale.ROOT); boolean hit = false;
            if (!disp.isEmpty() && !disp.equals(name)) for (String p : PAT) if (low.contains(p)) { hit = true; break; }
            if (!hit) for (String m : MARK) if (disp.contains(m)) { hit = true; break; }
            if (!hit) continue; now.add(name);
            if (seen.add(name)) { last = name; until = System.currentTimeMillis() + 6000; if (chat.b) mc.player.displayClientMessage(Component.literal("§c[Dutiner] §fStaff online: §e" + disp), false); }
        }
        seen.retainAll(now);
    }
    @Override public void hud(GuiGraphics g, Ctx c) {
        if (!banner.b || System.currentTimeMillis() > until) return;
        double t = Math.abs(Math.sin(System.currentTimeMillis() / 150.0)); String s = "STAFF: " + last;
        g.fill(c.w() / 2 - Draw.width(s) / 2 - 8, 14, c.w() / 2 + Draw.width(s) / 2 + 8, 30, Draw.lerp(0xCC400010, 0xCCB00020, t));
        Draw.textC(g, s, c.w() / 2, 18, 0xFFFFFFFF);
    }
}
