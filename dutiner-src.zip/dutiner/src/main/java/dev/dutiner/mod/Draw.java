package dev.dutiner.mod;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
public final class Draw {
    public static int rgb(int c, int a) { return (a << 24) | (c & 0xFFFFFF); }
    public static int lerp(int a, int b, double t) {
        t = Math.max(0, Math.min(1, t)); int o = 0;
        for (int s = 24; s >= 0; s -= 8) { int x = (a >> s) & 255, y = (b >> s) & 255; o |= (int) (x + (y - x) * t) << s; }
        return o;
    }
    public static void outline(GuiGraphics g, double x0, double y0, double x1, double y1, int c) {
        int a = (int) x0, b = (int) y0, d = (int) x1, e = (int) y1;
        g.fill(a, b, d + 1, b + 1, c); g.fill(a, e, d + 1, e + 1, c); g.fill(a, b, a + 1, e + 1, c); g.fill(d, b, d + 1, e + 1, c);
    }
    /** Đường thẳng bằng các ô fill 1–2px; chỉ vẽ phần trong màn hình. */
    public static void line(GuiGraphics g, double x0, double y0, double x1, double y1, int c, int w, int h) {
        double dx = x1 - x0, dy = y1 - y0; int n = (int) Math.min(1200, Math.max(Math.abs(dx), Math.abs(dy)));
        for (int i = 0; i <= n; i++) {
            double t = n == 0 ? 0 : (double) i / n; int x = (int) (x0 + dx * t), y = (int) (y0 + dy * t);
            if (x >= 0 && y >= 0 && x < w && y < h) g.fill(x, y, x + 1, y + 1, c);
        }
    }
    public static void text(GuiGraphics g, String s, int x, int y, int c) { g.drawString(Minecraft.getInstance().font, s, x, y, c, true); }
    public static void textC(GuiGraphics g, String s, int cx, int y, int c) { text(g, s, cx - Minecraft.getInstance().font.width(s) / 2, y, c); }
    public static int width(String s) { return Minecraft.getInstance().font.width(s); }
    /** Màu theo mức nguy hiểm: vàng → đỏ. */
    public static int heat(double t) { return lerp(0xFFFFD84A, 0xFFFF2D4D, t); }
}
