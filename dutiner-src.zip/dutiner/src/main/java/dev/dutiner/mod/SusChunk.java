package dev.dutiner.mod;
import dev.dutiner.core.*;
import net.minecraft.client.gui.GuiGraphics;
import java.util.*;
public final class SusChunk extends Module {
    public final Setting radius = add(Setting.num("Radius", 12, 4, 32, 2)), threshold = add(Setting.num("Threshold", 7, 2, 40, 1)),
        maxShown = add(Setting.num("Max shown", 10, 1, 30, 1)), outline = add(Setting.bool("Chunk outline", true)), labels = add(Setting.bool("Labels", true));
    public SusChunk() { super("Sus Chunk", Cat.RAID, "Tìm chunk có dấu hiệu bị xây/đào: kho, hopper, spawner, beacon, hoạt động block"); }
    public static String top(Intel.Result r) {
        List<Kind> ks = new ArrayList<>(r.sc.counts.keySet()); ks.sort(Comparator.comparingDouble((Kind k) -> -k.weight * r.sc.count(k)));
        StringBuilder sb = new StringBuilder(); for (int i = 0; i < Math.min(2, ks.size()); i++) sb.append(i > 0 ? " " : "").append(ks.get(i).name().toLowerCase()).append('×').append(r.sc.count(ks.get(i)));
        return sb.toString();
    }
    @Override public String info() { return String.valueOf(count); }
    int count;
    @Override public void hud(GuiGraphics g, Ctx c) {
        var scores = Intel.I.scores(); List<Map.Entry<Long, Double>> l = new ArrayList<>();
        int pcx = (int) Math.floor(c.eye().x) >> 4, pcz = (int) Math.floor(c.eye().z) >> 4, rad = radius.i();
        for (var e : scores.entrySet()) {
            int dx = ActivityTracker.kx(e.getKey()) - pcx, dz = ActivityTracker.kz(e.getKey()) - pcz;
            if (e.getValue() >= threshold.n && Math.abs(dx) <= rad && Math.abs(dz) <= rad) l.add(e);
        }
        l.sort((a, b) -> Double.compare(b.getValue(), a.getValue())); count = l.size();
        for (int i = 0; i < Math.min(l.size(), maxShown.i()); i++) {
            long k = l.get(i).getKey(); double s = l.get(i).getValue(); Intel.Result r = Intel.I.chunks.get(k); if (r == null) continue;
            int cx = ActivityTracker.kx(k), cz = ActivityTracker.kz(k); double y = Intel.I.avgY(r, c.eye().y);
            int col = Draw.heat((s - threshold.n) / 25.0) | 0xFF000000;
            if (outline.b) {
                double[][] p = new double[4][]; boolean ok = true;
                for (int j = 0; j < 4; j++) { p[j] = c.proj().project((cx + (j & 1)) * 16, y, (cz + (j >> 1)) * 16); if (p[j] == null) ok = false; }
                if (ok) { int[][] ed = {{0, 1}, {1, 3}, {3, 2}, {2, 0}}; for (int[] e : ed) Draw.line(g, p[e[0]][0], p[e[0]][1], p[e[1]][0], p[e[1]][1], col, c.w(), c.h()); }
            }
            double[] m = c.proj().project(cx * 16 + 8, y, cz * 16 + 8);
            if (m != null && labels.b && m[0] > 0 && m[0] < c.w() && m[1] > 0 && m[1] < c.h()) {
                double d = Math.hypot(cx * 16 + 8 - c.eye().x, cz * 16 + 8 - c.eye().z);
                Draw.textC(g, String.format("SUS %.1f  %dm", s, (int) d), (int) m[0], (int) m[1] - 10, col);
                Draw.textC(g, top(r), (int) m[0], (int) m[1], 0xFFDDDDDD);
            }
        }
    }
}
