package dev.dutiner.mod;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.phys.AABB;
public final class ItemEsp extends Module {
    public final Setting range = add(Setting.num("Range", 64, 16, 128, 8)), valuable = add(Setting.bool("Valuables only", false)), max = add(Setting.num("Max", 60, 10, 200, 10));
    public ItemEsp() { super("Item ESP", Cat.VISUAL, "Khung quanh vật phẩm rơi, nổi bật đồ giá trị (totem, netherite, elytra, shulker...)"); }
    static boolean val(String id) { return id.contains("netherite") || id.contains("totem") || id.contains("elytra") || id.contains("shulker") || id.contains("diamond") || id.contains("enchanted_golden") || id.contains("beacon") || id.contains("ancient_debris") || id.contains("end_crystal"); }
    @Override public void hud(GuiGraphics g, Ctx c) {
        int n = 0; AABB area = c.mc().player.getBoundingBox().inflate(range.n);
        for (ItemEntity e : c.mc().level.getEntitiesOfClass(ItemEntity.class, area)) {
            if (n >= max.i()) break; var st = e.getItem(); String id = net.minecraft.core.registries.BuiltInRegistries.ITEM.getKey(st.getItem()).getPath(); boolean v = val(id);
            if (valuable.b && !v) continue;
            double[] b = c.proj().box(e.getX() - .25, e.getY(), e.getZ() - .25, e.getX() + .25, e.getY() + .5, e.getZ() + .25); if (b == null) continue; n++;
            int col = v ? 0xFFFFD84A : 0xFF9AA0B5; Draw.outline(g, b[0], b[1], b[2], b[3], col);
            Draw.textC(g, st.getHoverName().getString() + (st.getCount() > 1 ? " x" + st.getCount() : ""), (int) ((b[0] + b[2]) / 2), (int) b[1] - 10, col);
        }
    }
}
