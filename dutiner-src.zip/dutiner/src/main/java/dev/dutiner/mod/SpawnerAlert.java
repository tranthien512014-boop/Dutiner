package dev.dutiner.mod;
import dev.dutiner.core.Kind;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import java.util.*;
public final class SpawnerAlert extends Module {
    public final Setting range = add(Setting.num("Range", 96, 16, 256, 16)), chat = add(Setting.bool("Chat", true));
    private final Set<Long> told = new HashSet<>();
    public SpawnerAlert() { super("Spawner Alert", Cat.RAID, "Báo toạ độ khi phát hiện spawner mới trong tầm quét"); }
    @Override public void onEnable() { told.clear(); }
    @Override public void tick(Minecraft mc) {
        if (mc.player == null || mc.player.tickCount % 40 != 0) return;
        for (var r : Intel.I.chunks.values()) for (var h : r.hits) {
            if (h.kind() != Kind.SPAWNER || !told.add(h.pos())) continue;
            int x = net.minecraft.core.BlockPos.getX(h.pos()), y = net.minecraft.core.BlockPos.getY(h.pos()), z = net.minecraft.core.BlockPos.getZ(h.pos());
            double d = Math.sqrt(mc.player.distanceToSqr(x + .5, y + .5, z + .5)); if (d > range.n) continue;
            if (chat.b) mc.player.displayClientMessage(Component.literal("§d[Dutiner] §fSpawner §e" + x + " " + y + " " + z + " §7(" + (int) d + "m)"), false);
        }
    }
}
