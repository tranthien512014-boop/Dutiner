package dev.dutiner.mod;
import dev.dutiner.core.*;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.chunk.LevelChunkSection;
import net.minecraft.world.level.chunk.status.ChunkStatus;
import java.util.*;
/** Dịch vụ quét chunk dùng chung cho SusChunk / BaseFinder / BlockEsp. Quét theo ngân sách thời gian mỗi tick → không lag. */
public final class Intel {
    public record Hit(long pos, Kind kind, String id) {}
    public static final class Result { public final ChunkScorer sc = new ChunkScorer(); public final List<Hit> hits = new ArrayList<>(); public long at; public int total; public double sumY; public int ny; }
    private record Info(Kind kind, String id, boolean watched) { boolean interesting() { return kind != Kind.OTHER || watched; } }

    public static final Intel I = new Intel();
    public final Map<Long, Result> chunks = new HashMap<>();
    public final ActivityTracker act = new ActivityTracker(1200);
    public Set<String> watch = Set.of();
    public long tick; public int radius = 12;
    private final IdentityHashMap<Block, Info> cache = new IdentityHashMap<>();
    private long[] order = new long[0]; private int cursor, lastCx = Integer.MIN_VALUE, lastCz, lastR;
    public int scannedLastTick; public double lastMs;
    private Map<Long, Double> scoreCache = Map.of(); private long scoreAt = -99;

    private Info info(Block b) {
        return cache.computeIfAbsent(b, k -> { String id = BuiltInRegistries.BLOCK.getKey(k).getPath(); Kind kd = Kind.of(id); if (kd == Kind.OTHER && !Kind.naturalLight(id) && k.defaultBlockState().getLightEmission() >= 7) kd = Kind.LIGHT; return new Info(kd, id, watch.contains(id)); });
    }
    public void setWatch(Set<String> w) { if (!w.equals(watch)) { watch = w; cache.clear(); chunks.clear(); scoreAt = -99; } }
    public void reset() { chunks.clear(); act.clear(); cache.clear(); order = new long[0]; scoreAt = -99; }

    public void tick(Minecraft mc, int rad, long budgetNs, int rescanTicks) {
        tick++; radius = rad; ClientLevel lv = mc.level; if (lv == null || mc.player == null) return;
        int pcx = mc.player.getBlockX() >> 4, pcz = mc.player.getBlockZ() >> 4;
        if (pcx != lastCx || pcz != lastCz || rad != lastR) rebuild(pcx, pcz, rad);
        long t0 = System.nanoTime(); int done = 0;
        for (int n = 0; n < order.length && System.nanoTime() - t0 < budgetNs; n++) {
            long k = order[cursor]; cursor = (cursor + 1) % order.length;
            Result old = chunks.get(k); if (old != null && tick - old.at < rescanTicks) continue;
            Result r = scan(lv, ActivityTracker.kx(k), ActivityTracker.kz(k)); if (r == null) continue;
            if (old != null && old.total != r.total) act.hit(ActivityTracker.kx(k), ActivityTracker.kz(k), Math.min(6, Math.abs(r.total - old.total)), tick);
            chunks.put(k, r); done++;
        }
        scannedLastTick = done; lastMs = (System.nanoTime() - t0) / 1e6;
        if (tick % 200 == 0) act.prune(tick);
    }
    private void rebuild(int pcx, int pcz, int r) {
        lastCx = pcx; lastCz = pcz; lastR = r; cursor = 0;
        List<Long> l = new ArrayList<>();
        for (int x = -r; x <= r; x++) for (int z = -r; z <= r; z++) l.add(ActivityTracker.key(pcx + x, pcz + z));
        l.sort(Comparator.comparingInt(k -> { int dx = ActivityTracker.kx(k) - pcx, dz = ActivityTracker.kz(k) - pcz; return dx * dx + dz * dz; }));
        order = l.stream().mapToLong(Long::longValue).toArray();
        chunks.keySet().removeIf(k -> Math.abs(ActivityTracker.kx(k) - pcx) > r + 2 || Math.abs(ActivityTracker.kz(k) - pcz) > r + 2);
    }
    private Result scan(ClientLevel lv, int cx, int cz) {
        LevelChunk ch = lv.getChunkSource().getChunk(cx, cz, ChunkStatus.FULL, false); if (ch == null) return null;
        Result r = new Result(); r.at = tick; LevelChunkSection[] secs = ch.getSections(); int minY = lv.getMinY();
        for (int i = 0; i < secs.length; i++) {
            LevelChunkSection s = secs[i]; if (s.hasOnlyAir() || !s.maybeHas(st -> info(st.getBlock()).interesting())) continue;
            int by = minY + i * 16;
            for (int y = 0; y < 16; y++) for (int z = 0; z < 16; z++) for (int x = 0; x < 16; x++) {
                BlockState st = s.getBlockState(x, y, z); Info in = info(st.getBlock()); if (!in.interesting()) continue;
                Kind kd = (in.kind == Kind.LIGHT && by + y < 0) ? Kind.DEEPLIGHT : in.kind;
                if (kd != Kind.OTHER) { r.sc.add(kd); r.total++; r.sumY += by + y; r.ny++; }
                if ((in.watched || kd.weight >= 2) && r.hits.size() < 400) r.hits.add(new Hit(BlockPos.asLong(cx * 16 + x, by + y, cz * 16 + z), kd, in.id));
            }
        }
        return r;
    }
    public double avgY(Result r, double def) { return r.ny == 0 ? def : r.sumY / r.ny; }
    /** Điểm từng chunk (cache 10 tick). */
    public Map<Long, Double> scores() {
        if (tick - scoreAt < 10) return scoreCache; scoreAt = tick;
        Map<Long, Double> m = new HashMap<>(chunks.size() * 2);
        chunks.forEach((k, r) -> { double s = r.sc.score(act.get(k, tick)); if (s > 0.5) m.put(k, s); });
        return scoreCache = m;
    }
}
