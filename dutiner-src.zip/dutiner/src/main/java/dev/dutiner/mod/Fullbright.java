package dev.dutiner.mod;
import net.minecraft.client.Minecraft;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
public final class Fullbright extends Module {
    private boolean applied;
    public Fullbright() { super("Fullbright", Cat.VISUAL, "Sáng tối đa (night vision phía client)"); }
    @Override public void tick(Minecraft mc) {
        var p = mc.player; if (p == null) return; var cur = p.getEffect(MobEffects.NIGHT_VISION);
        if (cur == null || cur.getDuration() < 400) { p.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 1200, 0, true, false, false)); applied = true; }
    }
    @Override public void onDisable() { var p = Minecraft.getInstance().player; if (applied && p != null) p.removeEffect(MobEffects.NIGHT_VISION); applied = false; }
}
