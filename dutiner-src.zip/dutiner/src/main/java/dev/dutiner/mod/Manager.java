package dev.dutiner.mod;
import com.google.gson.*;
import dev.dutiner.core.Projector;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import java.nio.file.*;
import java.util.*;
public final class Manager {
    public static final List<Module> all = new ArrayList<>(); public static boolean dirty;
    public static SusChunk sus; public static BaseFinder base; public static BlockEsp block; public static StorageEsp storage;
    private static long lastNs = System.nanoTime(); private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("dutiner.json");
    public static void init() {
        all.add(new HudModule()); all.add(sus = new SusChunk()); all.add(base = new BaseFinder()); all.add(storage = new StorageEsp()); all.add(block = new BlockEsp());
        all.add(new SpawnerAlert()); all.add(new PlayerEsp()); all.add(new ItemEsp()); all.add(new StaffAlert()); all.add(new Freecam()); all.add(new Fullbright()); load();
    }
    public static void tick(Minecraft mc) {
        if (mc.player == null || mc.level == null) return;
        boolean intel = sus.enabled || base.enabled || block.enabled || storage.enabled;
        if (intel) {
            Intel.I.setWatch(block.enabled ? block.watchSet() : Set.of());
            int r = Math.max(Math.max(sus.enabled ? sus.radius.i() : 0, base.enabled ? base.radius.i() : 0), Math.max(block.enabled ? (int) Math.ceil(block.radius.n / 16) : 0, storage.enabled ? (int) Math.ceil(storage.range.n / 16) : 0));
            Intel.I.tick(mc, Math.min(r + 1, mc.options.getEffectiveRenderDistance()), 2_000_000L, 400);
        }
        for (Module m : all) if (m.enabled) m.tick(mc);
        if (dirty && mc.screen == null) { save(); dirty = false; }
    }
    public static void hud(GuiGraphics g) {
        Minecraft mc = Minecraft.getInstance(); if (mc.player == null || mc.level == null || mc.options.hideGui) return;
        long now = System.nanoTime(); double d = Math.min(0.1, (now - lastNs) / 1e9); lastNs = now;
        float pt = mc.getDeltaTracker().getGameTimeDeltaPartialTick(false); var eye = mc.player.getEyePosition(pt); int w = g.guiWidth(), h = g.guiHeight();
        Projector p = new Projector(eye.x, eye.y, eye.z, mc.player.getViewYRot(pt), mc.player.getViewXRot(pt), mc.options.fov().get(), w, h);
        Ctx c = new Ctx(mc, p, eye, w, h, d);
        for (Module m : all) if (m.enabled || m instanceof HudModule) { if (m.enabled) m.hud(g, c); }
    }
    public static void save() {
        try { JsonObject o = new JsonObject();
            for (Module m : all) { JsonObject j = new JsonObject(); j.addProperty("on", m.enabled); for (Setting s : m.settings) j.add(s.name, s.save()); o.add(m.name, j); }
            Files.writeString(FILE, new GsonBuilder().setPrettyPrinting().create().toJson(o));
        } catch (Exception ignored) {}
    }
    private static void load() {
        try { if (!Files.exists(FILE)) return; JsonObject o = JsonParser.parseString(Files.readString(FILE)).getAsJsonObject();
            for (Module m : all) { if (!o.has(m.name)) continue; JsonObject j = o.getAsJsonObject(m.name);
                for (Setting s : m.settings) if (j.has(s.name)) s.load(j.get(s.name));
                boolean on = j.has("on") && j.get("on").getAsBoolean(); m.enabled = on; m.toggle.v = m.toggle.target = on ? 1 : 0; }
        } catch (Exception ignored) {}
    }
}
