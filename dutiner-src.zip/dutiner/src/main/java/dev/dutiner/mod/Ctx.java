package dev.dutiner.mod;
import dev.dutiner.core.Projector;
import net.minecraft.client.Minecraft;
import net.minecraft.world.phys.Vec3;
/** Dữ liệu 1 frame HUD: người chơi, camera, projector. */
public record Ctx(Minecraft mc, Projector proj, Vec3 eye, int w, int h, double dt) {}
