package dev.dutiner.mod;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
public final class PlayerEsp extends Module {
    public final Setting range = add(Setting.num("Range", 128, 32, 256, 16)), health = add(Setting.bool("Health", true)), tracers = add(Setting.bool("Tracers", true)), held = add(Setting.bool("Held item", true));
    public PlayerEsp() { super("Player ESP", Cat.VISUAL, "Khung 2D, tên, máu, khoảng cách người chơi xuyên tường"); }
    @Override public void hud(GuiGraphics g, Ctx c) {
        float pt = c.mc().getDeltaTracker().getGameTimeDeltaPartialTick(false);
        for (Player p : c.mc().level.players()) {
            if (p == c.mc().player || p.isSpectator()) continue;
            double d = p.distanceTo(c.mc().player); if (d > range.n) continue;
            double x = p.xo + (p.getX() - p.xo) * pt, y = p.yo + (p.getY() - p.yo) * pt, z = p.zo + (p.getZ() - p.zo) * pt; AABB bb = p.getBoundingBox();
            double hw = (bb.maxX - bb.minX) / 2, h = bb.maxY - bb.minY;
            double[] b = c.proj().box(x - hw, y, z - hw, x + hw, y + h, z + hw); if (b == null) continue;
            int col = Draw.lerp(0xFFFF4D4D, 0xFF5CFFB0, Math.min(1, p.getHealth() / 20.0)); if (p.isCrouching()) col = 0xFFFFD84A;
            Draw.outline(g, b[0], b[1], b[2], b[3], col);
            String s = p.getName().getString() + " " + (int) d + "m"; Draw.textC(g, s, (int) ((b[0] + b[2]) / 2), (int) b[1] - 10, 0xFFFFFFFF);
            if (health.b) { double t = Math.max(0, Math.min(1, p.getHealth() / p.getMaxHealth())); g.fill((int) b[0] - 4, (int) b[1], (int) b[0] - 2, (int) b[3], 0x90000000); g.fill((int) b[0] - 4, (int) (b[3] - (b[3] - b[1]) * t), (int) b[0] - 2, (int) b[3], col); }
            if (held.b && !p.getMainHandItem().isEmpty()) Draw.textC(g, p.getMainHandItem().getHoverName().getString(), (int) ((b[0] + b[2]) / 2), (int) b[3] + 2, 0xFFB8BDD0);
            if (tracers.b) { double[] m = c.proj().project(x, y + h / 2, z); if (m != null) Draw.line(g, c.w() / 2.0, c.h(), m[0], m[1], Draw.rgb(col, 130), c.w(), c.h()); }
        }
    }
}
