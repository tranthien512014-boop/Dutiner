package dev.dutiner.mod;
import dev.dutiner.core.Anim;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import java.util.*;
public abstract class Module {
    public enum Cat { VISUAL("Visual"), RAID("Raid"), UTILITY("Utility"); public final String label; Cat(String l) { label = l; } }
    public final String name, desc; public final Cat cat; public boolean enabled;
    public final List<Setting> settings = new ArrayList<>();
    public final Anim toggle = new Anim(0, 14), hover = new Anim(0, 18), open = new Anim(0, 14), slide = new Anim(0, 12);
    public boolean expanded;
    protected Module(String name, Cat cat, String desc) { this.name = name; this.cat = cat; this.desc = desc; }
    protected <S extends Setting> S add(S s) { settings.add(s); return s; }
    public void setEnabled(boolean e) { if (e == enabled) return; enabled = e; if (e) onEnable(); else onDisable(); Manager.dirty = true; }
    public void flip() { setEnabled(!enabled); }
    public void onEnable() {}
    public void onDisable() {}
    public void tick(Minecraft mc) {}
    public void hud(GuiGraphics g, Ctx c) {}
    public String info() { return ""; }
}
