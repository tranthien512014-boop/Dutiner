package dev.dutiner.mixin;
import dev.dutiner.mod.Freecam;
import net.minecraft.client.Camera;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(Camera.class)
public abstract class CameraMixin {
    @Shadow protected abstract void setPosition(double x, double y, double z);
    @Shadow protected abstract void setRotation(float yaw, float pitch);
    @Inject(method = "setup", at = @At("TAIL"))
    private void dutiner$freecam(Level level, Entity entity, boolean thirdPerson, boolean inverseView, float pt, CallbackInfo ci) {
        Freecam f = Freecam.INSTANCE; if (f == null || !f.enabled || !f.live) return;
        setRotation(f.camYaw, f.camPitch);
        setPosition(f.lx(pt), f.ly(pt), f.lz(pt));
    }
}
