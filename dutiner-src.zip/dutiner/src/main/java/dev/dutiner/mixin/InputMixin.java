package dev.dutiner.mixin;
import dev.dutiner.mod.Freecam;
import net.minecraft.client.player.Input;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(Input.class)
public class InputMixin {
    @Inject(method = "tick", at = @At("TAIL"))
    private void dutiner$freeze(CallbackInfo ci) {
        Freecam f = Freecam.INSTANCE; if (f == null || !f.enabled || !f.live) return;
        Input in = (Input)(Object)this;
        in.keyPresses = new net.minecraft.world.entity.player.Input(false,false,false,false,false,in.keyPresses.sneak(),false);
        in.leftImpulse = 0; in.forwardImpulse = 0;
    }
}
