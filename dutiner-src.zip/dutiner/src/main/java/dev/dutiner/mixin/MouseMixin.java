package dev.dutiner.mixin;
import dev.dutiner.mod.Freecam;
import net.minecraft.client.MouseHandler;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(MouseHandler.class)
public class MouseMixin {
    @Inject(method = "turnPlayer", at = @At("HEAD"), cancellable = true)
    private void dutiner$look(double dt, CallbackInfo ci) {
        Freecam f = Freecam.INSTANCE; if (f == null || !f.enabled || !f.live) return;
        ci.cancel();
        net.minecraft.client.Minecraft mc = net.minecraft.client.Minecraft.getInstance();
        double sx = mc.getWindow().getScreenWidth(), sy = mc.getWindow().getScreenHeight();
        double dx = mc.mouseHandler.xpos() - sx/2, dy = mc.mouseHandler.ypos() - sy/2;
        f.camYaw   += (float)(dx * 0.15);
        f.camPitch  = net.minecraft.util.Mth.clamp(f.camPitch + (float)(dy * 0.15), -90f, 90f);
    }
}
