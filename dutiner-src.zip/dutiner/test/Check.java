import dev.dutiner.core.*; import java.util.*;
public class Check {
  static int f=0; static void ok(boolean c,String m){ if(!c){f++;System.out.println("FAIL "+m);} }
  public static void main(String[] a){
    ok(Kind.of("chest")==Kind.STORAGE && Kind.of("red_shulker_box")==Kind.SHULKER && Kind.of("stone")==Kind.OTHER,"kind");
    ChunkScorer s=new ChunkScorer(); for(int i=0;i<1000;i++) s.add(Kind.BUILD); double wood=s.score(0);
    ChunkScorer b=new ChunkScorer(); b.add(Kind.BEACON); b.add(Kind.STORAGE); b.add(Kind.HOPPER);
    ok(b.score(0)>wood*0.8,"beacon base ~ comparable to 1000 wood: "+b.score(0)+" vs "+wood);
    ChunkScorer c1=new ChunkScorer(); c1.add(Kind.STORAGE); ChunkScorer c2=new ChunkScorer(); c2.add(Kind.STORAGE); c2.add(Kind.HOPPER);
    ok(c2.score(0)>c1.score(0),"combo bonus");
    Map<Long,Double> m=new HashMap<>(); m.put(ActivityTracker.key(0,0),9.0); m.put(ActivityTracker.key(2,0),8.0); m.put(ActivityTracker.key(20,20),7.0); m.put(ActivityTracker.key(-3,-3),1.0);
    var cl=ClusterFinder.find(m,5,1); ok(cl.size()==2 && cl.get(0).size()==2,"cluster gap1 -> "+cl);
    ok(ClusterFinder.find(m,5,0).size()==3,"cluster gap0");
    ok(ActivityTracker.kx(ActivityTracker.key(-5,7))==-5 && ActivityTracker.kz(ActivityTracker.key(-5,-7))==-7,"key neg");
    ActivityTracker t=new ActivityTracker(100); t.hit(1,1,10,0); ok(Math.abs(t.get(ActivityTracker.key(1,1),100)-5)<1e-6,"halflife");
    Projector p=new Projector(0,0,0,0,0,70,1000,500); // nhìn +Z
    double[] c=p.project(0,0,10); ok(c!=null&&Math.abs(c[0]-500)<1e-6&&Math.abs(c[1]-250)<1e-6,"center");
    double[] r=p.project(-2,0,10); ok(r[0]>500,"-X nằm bên phải khi nhìn +Z");
    double[] u=p.project(0,2,10); ok(u[1]<250,"cao hơn → y nhỏ hơn");
    ok(p.project(0,0,-5)==null,"behind");
    Projector w=new Projector(0,0,0,90,0,70,1000,500); double[] l=w.project(-10,0,0); ok(l!=null&&Math.abs(l[0]-500)<1e-6,"yaw90 nhìn -X");
    Projector d=new Projector(0,0,0,0,45,70,1000,500); double[] dn=d.project(0,-10,10); ok(dn!=null&&Math.abs(dn[1]-250)<1e-6,"pitch45 nhìn xuống");
    Anim an=new Anim(0,10); an.set(1); for(int i=0;i<100;i++) an.tick(0.016); ok(an.v==1,"anim converge");
    System.out.println(f==0?"ALL PASS":"FAILED "+f);
  }}
